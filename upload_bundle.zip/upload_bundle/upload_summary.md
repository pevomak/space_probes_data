# Upload Bundle Summary

Generated: 2026-04-10T07:08:01.414942

## all_records.jsonl

- Records: 6366550
- Record types: {'table_row': 6156298, 'text_line': 191713, 'memory_word': 17741, 'idl_assignment': 795, 'idl_procedure': 3}
- Missions: {'ace': 4411901, 'unknown': 1930007, 'wind': 18342, 'helios': 4877, 'ulysses': 1105, 'galileo': 126, 'parker': 95, 'pioneer': 78, 'voyager': 19}
- Instruments: {'mag': 6020406, 'unknown': 319655, 'fields': 26311, 'pls': 97, 'epi': 81}
- Models: {'general': 6353101, 'instrument_calibration': 10029, 'telemetry_memory': 2671, 'alfvenic_transport': 496, 'turbulence_intermittency': 294, 'boundary_plasma': 70}
- Top keywords: [('e-04', 11691193), ('e-05', 8273199), ('e-03', 3624658), ('bx45', 958094), ('e-06', 795657), ('e-02', 446381), ('e-01', 47146), ('t00', 10724), ('cdf', 10721), ('t08', 9274), ('t14', 9235), ('t23', 8956), ('t09', 8784), ('t22', 8672), ('t07', 8569)]
- Sample records:
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 4, "raw": "For data processed through NSSDC's Y2K-developed DIOnAS software, NSSDC"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 5, "raw": "provides directories for holding attribute files that are companions to the"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 6, "raw": "associated data files.  An 'attribute' (sometimes 'attrib') directory is"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 7, "raw": "provided in the same directory that contains a given set of data files."}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 8, "raw": "The files in the 'attribute' directory have the same names as the data"}

## all_artifacts.jsonl

- Records: 3251
- Artifact types: {'parameter': 3084, 'definition': 148, 'logic': 18, 'equation': 1}
- Missions: {'unknown': 2470, 'ace': 557, 'wind': 203, 'ulysses': 10, 'helios': 9, 'voyager': 1, 'pioneer': 1}
- Instruments: {'unknown': 2926, 'mag': 313, 'fields': 12}
- Models: {'general': 3157, 'instrument_calibration': 65, 'telemetry_memory': 27, 'alfvenic_transport': 4, 'boundary_plasma': 2, 'turbulence_intermittency': 1}
- Top keywords: []
- Sample records:
  - {"artifact_type": "definition", "mission": "ace", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/software/cdawlib/CDAWeb_NASA_Open_Source_Agreement_1.3.txt"}
  - {"artifact_type": "definition", "mission": "ace", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/software/cdawlib/CDAWeb_NASA_Open_Source_Agreement_1.3.txt"}
  - {"artifact_type": "parameter", "mission": "wind", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/software/format_conversion/conv_unix_vax.pro", "field": "little_endian", "value": 0}
  - {"artifact_type": "parameter", "mission": "wind", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/software/format_conversion/conv_unix_vax.pro", "field": "little_endian", "value": 1}
  - {"artifact_type": "parameter", "mission": "wind", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/software/format_conversion/conv_unix_vax.pro", "field": "little_endian", "value": 1}

## general.jsonl

- Records: 6353388
- Record types: {'table_row': 6154709, 'text_line': 180181, 'memory_word': 17741, 'idl_assignment': 754, 'idl_procedure': 3}
- Missions: {'ace': 4408869, 'unknown': 1921681, 'wind': 16780, 'helios': 4756, 'ulysses': 1009, 'galileo': 116, 'parker': 84, 'pioneer': 74, 'voyager': 19}
- Instruments: {'mag': 6018614, 'unknown': 308439, 'fields': 26165, 'pls': 95, 'epi': 75}
- Models: {'general': 6353388}
- Top keywords: [('e-04', 11691193), ('e-05', 8273199), ('e-03', 3624658), ('bx45', 958094), ('e-06', 795657), ('e-02', 446381), ('e-01', 47146), ('t00', 10720), ('cdf', 9368), ('t08', 9273), ('t14', 9235), ('t23', 8955), ('t09', 8782), ('t22', 8669), ('t07', 8568)]
- Sample records:
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 4, "raw": "For data processed through NSSDC's Y2K-developed DIOnAS software, NSSDC"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 5, "raw": "provides directories for holding attribute files that are companions to the"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 6, "raw": "associated data files.  An 'attribute' (sometimes 'attrib') directory is"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 7, "raw": "provided in the same directory that contains a given set of data files."}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["general"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 8, "raw": "The files in the 'attribute' directory have the same names as the data"}

## instrument_calibration.jsonl

- Records: 10029
- Record types: {'text_line': 9093, 'table_row': 925, 'idl_assignment': 11}
- Missions: {'unknown': 8304, 'ace': 1005, 'wind': 582, 'ulysses': 78, 'helios': 53, 'pioneer': 3, 'galileo': 2, 'parker': 2}
- Instruments: {'unknown': 9559, 'mag': 391, 'fields': 75, 'pls': 2, 'epi': 2}
- Models: {'instrument_calibration': 10029, 'telemetry_memory': 51, 'alfvenic_transport': 14, 'boundary_plasma': 4}
- Top keywords: [('information', 4880), ('format', 1944), ('all', 1360), ('idl', 1339), ('may', 1308), ('cdf', 1308), ('not', 1177), ('subject', 1159), ('however', 1159), ('visual', 1155), ('inc', 1155), ('reserved', 1155), ('exelis', 1154), ('solutions', 1154), ('subsidiary', 1154)]
- Sample records:
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "models": ["instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 13, "raw": "an NSSDC Archival Information Package (AIP).  NSSDC AIPs facilitate the"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 14, "raw": "long term preservation of archived information and are independent of the"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["boundary_plasma", "instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 36, "raw": "packaging such as would be needed to capture record boundary information"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 46, "raw": "Authority Office, for a description of the format and content of this"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 49, "raw": "The Supporting_Attributes provide a few additional pieces of information"}

## boundary_plasma.jsonl

- Records: 70
- Record types: {'text_line': 42, 'table_row': 28}
- Missions: {'wind': 24, 'ace': 23, 'helios': 17, 'unknown': 6}
- Instruments: {'unknown': 45, 'mag': 25}
- Models: {'boundary_plasma': 70, 'instrument_calibration': 4, 'telemetry_memory': 4}
- Top keywords: [('boundary', 33), ('bow', 12), ('shock', 11), ('nose', 9), ('interstellar', 9), ('layers', 9), ('definitive', 7), ('magnetospheric', 7), ('plasma', 6), ('earth', 6), ('event', 6), ('compositional', 6), ('proc', 6), ('esa', 6), ('sp-148', 6)]
- Sample records:
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["boundary_plasma", "instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 36, "raw": "packaging such as would be needed to capture record boundary information"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["boundary_plasma"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 4669, "raw": "voyager/voyager2/plasma_cdaweb/hires_plasma/heliosheath voyager2_pls_hires_plasma_data_hsh"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["boundary_plasma", "instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 36, "raw": "packaging such as would be needed to capture record boundary information"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["boundary_plasma"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 4669, "raw": "voyager/voyager2/plasma_cdaweb/hires_plasma/heliosheath voyager2_pls_hires_plasma_data_hsh"}
  - {"record_type": "text_line", "mission": "wind", "instrument": "unknown", "models": ["boundary_plasma", "instrument_calibration"], "source": "https://spdf.gsfc.nasa.gov/pub/event_lists/Lepping%20and%20Berdichevsky%20-%20ISTP%20Solar%20Wind%20Catalog.txt", "line_no": 15, "raw": "# Description: Candidate Events for Further Study are listed in chronological order; the category colums lists the event types as defined above. The s/c column identifies the spacecraft (W=WIND, 8=IMP-8) that observed the 

## telemetry_memory.jsonl

- Records: 2671
- Record types: {'text_line': 2127, 'table_row': 515, 'idl_assignment': 29}
- Missions: {'ace': 1709, 'wind': 628, 'unknown': 270, 'helios': 47, 'galileo': 8, 'parker': 5, 'ulysses': 3, 'pioneer': 1}
- Instruments: {'mag': 1426, 'unknown': 1184, 'fields': 59, 'epi': 2}
- Models: {'telemetry_memory': 2671, 'instrument_calibration': 51, 'alfvenic_transport': 27, 'boundary_plasma': 4, 'turbulence_intermittency': 2}
- Top keywords: [('telemetry', 679), ('due', 614), ('frame', 595), ('solar-orbiter', 418), ('orbit', 397), ('science', 380), ('satellite', 347), ('are', 345), ('mode', 324), ('also', 311), ('could', 305), ('switches', 304), ('there', 304), ('noise', 303), ('unreliable', 299)]
- Sample records:
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 71, "raw": "         STREAM_TYPE = \"7-BIT ASCII\";"}
  - {"record_type": "text_line", "mission": "unknown", "instrument": "unknown", "models": ["telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 86, "raw": "         STREAM_TYPE = \"7-BIT ASCII\";"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "fields", "models": ["telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/00readme.txt", "line_no": 25, "raw": "SPDF also has extensive web services for getting data files, plots, listings, orbits:"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "fields", "models": ["telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/00readme.txt", "line_no": 28, "raw": "SSCweb <https://sscweb.gsfc.nasa.gov/WebServices/REST/> for orbits"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 34, "raw": "ace/orbit/level_2_cdaweb/or_ssc ac_or_ssc"}

## alfvenic_transport.jsonl

- Records: 496
- Record types: {'text_line': 286, 'table_row': 209, 'idl_assignment': 1}
- Missions: {'ace': 230, 'wind': 223, 'ulysses': 21, 'unknown': 11, 'helios': 7, 'parker': 4}
- Instruments: {'unknown': 283, 'mag': 198, 'fields': 13, 'epi': 2}
- Models: {'alfvenic_transport': 496, 'telemetry_memory': 27, 'instrument_calibration': 14, 'turbulence_intermittency': 11}
- Top keywords: [('wave', 141), ('waves', 129), ('plasma', 94), ('radio', 51), ('wind', 45), ('field', 42), ('cluster', 40), ('wavelength', 40), ('waveform', 38), ('solar', 35), ('emfisis', 32), ('frequency', 32), ('electric', 30), ('berkeley', 30), ('vlf', 30)]
- Sample records:
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1162, "raw": "cluster/c1/sta/mfield_calibwaveform_gse c1_cp_sta_cwf_gse"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1163, "raw": "cluster/c2/sta/mfield_calibwaveform_gse c2_cp_sta_cwf_gse"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1164, "raw": "cluster/c3/sta/mfield_calibwaveform_gse c3_cp_sta_cwf_gse"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1165, "raw": "cluster/c4/sta/mfield_calibwaveform_gse c4_cp_sta_cwf_gse"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1182, "raw": "cluster/c1/whi/efield_integratedpowerdensity_naturalmode c1_cp_whi_wave_form_energy"}

## turbulence_intermittency.jsonl

- Records: 294
- Record types: {'table_row': 251, 'text_line': 43}
- Missions: {'wind': 183, 'ace': 79, 'unknown': 29, 'helios': 3}
- Instruments: {'unknown': 245, 'mag': 49}
- Models: {'turbulence_intermittency': 294, 'alfvenic_transport': 11, 'telemetry_memory': 2}
- Top keywords: [('spectrum', 247), ('x-ray', 166), ('resolution', 165), ('robyn', 165), ('millan', 165), ('time', 160), ('dartmouth', 113), ('fast', 52), ('bremsstrahlung', 52), ('medium', 52), ('slow', 52), ('anisotropy', 33), ('proton', 32), ('channel', 18), ('anisot', 18)]
- Sample records:
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport", "turbulence_intermittency"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1615, "raw": "voyager/voyager1/wave_spectra_pws/spectrum_analyzer_cdf vg1_pws_lr"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport", "turbulence_intermittency"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1616, "raw": "voyager/voyager2/wave_spectra_pws/spectrum_analyzer_cdf vg2_pws_lr"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport", "turbulence_intermittency"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1615, "raw": "voyager/voyager1/wave_spectra_pws/spectrum_analyzer_cdf vg1_pws_lr"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "mag", "models": ["alfvenic_transport", "turbulence_intermittency"], "source": "https://spdf.gsfc.nasa.gov/pub/catalogs/CDAWebdataset-dirs.txt", "line_no": 1616, "raw": "voyager/voyager2/wave_spectra_pws/spectrum_analyzer_cdf vg2_pws_lr"}
  - {"record_type": "text_line", "mission": "ace", "instrument": "unknown", "models": ["turbulence_intermittency", "telemetry_memory"], "source": "https://spdf.gsfc.nasa.gov/pub/models/orbital_radiation_package_orp/SPMS-00795_nmc.html", "line_no": 58, "raw": "          The Orbital Radiation Package (ORP) is a FORTRAN routine available on tape designed to calculate the average geomagnetically trapped radiation accumulated by an earth-orbiting vehicle. ORP requires an input tape containing the B- and 

## decoded_records.jsonl

- Records: 200000
- Record types: {'memory_word': 113861, 'table_row': 85495, 'idl_assignment': 247, 'idl_comment': 245, 'text_block': 86, 'table_header': 64, 'idl_procedure': 2}
- Missions: {'unknown': 199977, 'pioneer': 20, 'voyager': 3}
- Instruments: {'unknown': 199991, 'mag': 9}
- Models: {}
- Top keywords: [('sai00', 35306), ('c2f', 12992), ('satm', 7911), ('sai20', 6871), ('a3f', 5141), ('nammap0x', 5031), ('c2r', 4710), ('sh16m03x', 3912), ('sai30', 3834), ('sh16m02x', 3822), ('bbf', 3650), ('stopit', 3373), ('ccf', 3121), ('t816q02x', 2730), ('a4f', 2263)]
- Sample records:
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 6, "raw": "associated data files.  An 'attribute' (sometimes 'attrib') directory is"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 13, "raw": "an NSSDC Archival Information Package (AIP).  NSSDC AIPs facilitate the"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 15, "raw": "underlying media types, including file structures.  This is achieved by"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 17, "raw": "number of functions.  These include identification of the type of attribute"}
  - {"record_type": "table_row", "mission": "unknown", "instrument": "unknown", "source": "https://spdf.gsfc.nasa.gov/pub/documents/attribute_files.txt", "line_no": 24, "raw": "\"Supporting_Attributes\".  The Original_Stream Structure attributes provide"}

